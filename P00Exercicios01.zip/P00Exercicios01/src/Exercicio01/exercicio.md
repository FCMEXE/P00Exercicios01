Exercício 1
Crie a seguinte classe em java e implemente o menu:
Pessoa
- CPF:String
- Nome:String
- Sexo :char
- Idade:int
+ setCPF(cpf:String)
+ getCPF():String
+ setNome(nome:String)
+ getNome():String
+ setIdade(idade:int)
+ getIdade():int
+ setSexo(sexo:char)
+ getSexo():char
  +imprimir():String
  Menu:
  1 – Criar pessoa
  2 – Mostrar pessoa
  3 – Sair